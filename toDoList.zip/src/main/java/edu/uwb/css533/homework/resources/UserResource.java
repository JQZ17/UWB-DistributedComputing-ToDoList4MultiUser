package edu.uwb.css533.homework.resources;

import edu.uwb.css533.homework.DatabaseConnection;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

///http://server:port/path?param=something
//path
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
public class UserResource {
    DatabaseConnection databaseConnection;
    @GET
    @Path("{userName}/{userPassword}/addList/{listName}/{listType}")
    public Response addList(
            @PathParam("userName") String userName,
            @PathParam("userPassword") String userPassword,
            @PathParam("listName") String listName,
            @PathParam("listType") String listType) {
            if(databaseConnection.logIn(userName,userPassword)){
                boolean success = databaseConnection.addList(userName,listName,listType);
                if(success){
                    System.out.println( listType +" list " + listName + " has been added for user: " + userName);
                }
                else{
                    System.out.println(" Adding " +listType +" list " +listName + "for user: "+ userName + "has failed");
                }
            }
            else{
                System.out.println("Incorrect user or password");
            }
            return Response.ok().build();
    }


}
